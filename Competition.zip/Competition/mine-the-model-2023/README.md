 **Data will be made available when the competition starts i.e. on 31st October.**
